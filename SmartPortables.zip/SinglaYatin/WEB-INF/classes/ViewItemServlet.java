import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.event.ListDataEvent;

public class ViewItemServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        HttpSession session = request.getSession();
        String username = (String)session.getAttribute("username");
		String category=null;
        category = request.getParameter("category");
        if(category == null){
            category = (String)session.getAttribute("category");
            session.setAttribute("category", category);
        }

        String proId = request.getParameter("id");
        	
		ServletContext sc = request.getServletContext();
		String filename= sc.getRealPath("WEB-INF/XMLFiles/ProductCatalog.xml");
        SaxParser4SmartPortableXMLdatastore productDetails = new SaxParser4SmartPortableXMLdatastore(filename);
        PrintWriter out = response.getWriter();

        ArrayList<Smartwatch> smartwatchList = new ArrayList<Smartwatch>();
		HashMap<String,List<Smartwatch>> swhashObj = new HashMap<String,List<Smartwatch>>();
		swhashObj.put("smartwatch", productDetails.smartwatches);

        ArrayList<Headphone> headphoneList = new ArrayList<Headphone>();
		HashMap<String,List<Headphone>> hphashObj = new HashMap<String,List<Headphone>>();
		hphashObj.put("headphone", productDetails.headphones);

        ArrayList<Speaker> sparraylist = new ArrayList<Speaker>();
        HashMap<String,List<Speaker>> sphashObj = new HashMap<String,List<Speaker>>();
		sphashObj.put("speaker", productDetails.speakers);

        ArrayList<Phone> pharraylist = new ArrayList<Phone>();
		HashMap<String,List<Phone>> phhashObj = new HashMap<String,List<Phone>>();
		phhashObj.put("phone", productDetails.phones);

        ArrayList<Laptop> lparraylist = new ArrayList<Laptop>();
        HashMap<String,List<Laptop>> lphashObj = new HashMap<String,List<Laptop>>();
		lphashObj.put("laptop", productDetails.laptops);

        ArrayList<ExternalStorage> esarraylist = new ArrayList<ExternalStorage>();
		HashMap<String,List<ExternalStorage>> eshashObj = new HashMap<String,List<ExternalStorage>>();
		eshashObj.put("externalstorage", productDetails.externals);

        ArrayList<Accessory> acarraylist = new ArrayList<Accessory>();
		HashMap<String,List<Accessory>> achashObj = new HashMap<String,List<Accessory>>();
		achashObj.put("accessory", productDetails.accessories);

        out.println("<!doctype html>");
    out.println("<html>");
        out.println("<head>");
            out.println("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />");
            out.println("<title>Smart Portables</title>");
            out.println("<link rel=\"stylesheet\" href=\"styles.css\" type=\"text/css\" />");
            out.println("<link rel=\"stylesheet\" href=\"http://netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap-glyphicons.css\" type=\"text/css\" />");    
            out.println("<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js\"></script>");
            out.println("<script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js\"></script>");
        out.println("</head>");
        out.println("<body>");
            out.println("<div id=\"container\">");
                out.println("<header>");
                    out.println("<h1><a href=\"/\">Smart<span>Portables</span></a></h1>");
                    out.println("<h2></h2>");
                out.println("</header>");
                if(username!=null){
                    out.println("<p style=\"text-align:right;font-size:20px;\">Hello "+ username +"</p>");
                }
                out.println("<nav>");
                    out.println("<ul>");
                    out.println("<li class=\"start selected\"><a href=\"Home\">Home</a></li>");
                        out.println("<li><a href=\"#\">Contact</a></li>");
                        out.println("<li><input type=\"text\" name=\"search\" class=\"search\" placeholder=\"Search..\"></li>");                       
                        out.println("<li><a href=\"LogoutServlet\">Logout</a></li>");

                        HashMap<String,Usercart> carthashObj = new HashMap<String,Usercart>();
                        carthashObj = (HashMap)session.getAttribute("sessionCart");
                        if(carthashObj == null){
                            carthashObj = new HashMap<String,Usercart>();
                        }
                        String cartCount = String.valueOf(carthashObj.size());
	                    
                        out.println("<li><a href=\"AddtoCartServlet\">Cart("+ cartCount +")</a></li>");			
                    out.println("</ul>");
                out.println("</nav>");
	            out.println("<img class=\"header-image\" src=\"images/image.jpg\" alt=\"\" />");
                out.println("<div id=\"body\">");
	                out.println("<section id=\"content\">");
                    	out.println("<article>");
                        out.println("<h2>Products</h2>");
                            out.println("<ul class=\"products\">");

                            if(category.equals("smartwatch")){
                                for(Map.Entry<String,List<Smartwatch>> map : swhashObj.entrySet()){
                                    for(Smartwatch list : map.getValue()){
                                        if(list.getId().equals(proId)){
                                            session.setAttribute("id", list.getId());
                                            session.setAttribute("price",list.getPrice());
                                            session.setAttribute("name", list.getName());
                                            
                                            carthashObj = (HashMap)session.getAttribute("sessionCart");
                                            if(carthashObj == null){
                                                carthashObj = new HashMap<String,Usercart>();
                                            }
                                            
                                            Usercart usercart = new Usercart();
                                            usercart.setProductId(list.getId());
                                            usercart.setPrice(list.getPrice());
                                            usercart.setProductName(list.getName());
                                            usercart.quantity = 1;

                                            carthashObj.put(String.valueOf(usercart.getProductId()), usercart);
	    	                                session.setAttribute("sessionCart", carthashObj);

                                            out.println("<li>");
                                                out.println("<img src=\"images/" + list.getImage() + "\" alt=\"Smartwatch\">");
                                                out.println("<h4>" + list.getName() + "</h4>");
                                                out.println("<p> Price-"+list.getPrice()+", Id-"+ list.getId()+", Retailer-"+ list.getRetailer()+", Condition-" + list.getCondition() +", Discount-" + list.getDiscount() + "</p>");                                   
                                                out.println("<a href='AddtoCartServlet?id="+ list.getId() +"' class='btn btn-info' role='button'>Add to cart</a>");
                                                out.println("<br>");
                                                out.println("<br>");
                                                out.println("<a href='WriteReviewServlet?name="+list.getName()+"&retailer="+list.getRetailer()+"&price="+list.getPrice()+"' class='btn btn-info' role='button'>Write Review</a>");
                                                out.println("<br>");
                                                out.println("<br>");
                                                out.println("<a href='ViewReviewServlet?name="+list.getName()+"' class='btn btn-info' role='button'>View Review</a>");
                                            out.println("</li>");
                                        }
                                    }
                                }
                            }

                            else if(category.equals("speaker")){
                                for(Map.Entry<String,List<Speaker>> map : sphashObj.entrySet()){
                                    for(Speaker list : map.getValue()){
                                        if(list.getId().equals(proId)){
                                            session.setAttribute("id", list.getId());
                                            session.setAttribute("price",list.getPrice());
                                            session.setAttribute("name", list.getName());
                                            
                                            carthashObj = (HashMap)session.getAttribute("sessionCart");
                                            if(carthashObj == null){
                                                carthashObj = new HashMap<String,Usercart>();
                                            }
                                            
                                            Usercart usercart = new Usercart();
                                            usercart.setProductId(list.getId());
                                            usercart.setPrice(list.getPrice());
                                            usercart.setProductName(list.getName());
                                            usercart.quantity = 1;

                                            carthashObj.put(String.valueOf(usercart.getProductId()), usercart);
	    	                                session.setAttribute("sessionCart", carthashObj);

                                            out.println("<li>");
                                                out.println("<img src=\"images/" + list.getImage() + "\" alt=\"Smartwatch\">");
                                                out.println("<h4>" + list.getName() + "</h4>");
                                                out.println("<p> Price-"+list.getPrice()+", Id-"+ list.getId()+", Retailer-"+ list.getRetailer()+", Condition-" + list.getCondition() +", Discount-" + list.getDiscount() + "</p>");                                   
                                                out.println("<a href='AddtoCartServlet?id="+ list.getId() +"' class='btn btn-info' role='button'>Add to cart</a>");
                                                out.println("<br>");
                                                out.println("<br>");
                                                out.println("<a href='WriteReviewServlet?name="+list.getName()+"&retailer="+list.getRetailer()+"&price="+list.getPrice()+"' class='btn btn-info' role='button'>Write Review</a>");
                                                out.println("<br>");
                                                out.println("<br>");
                                                out.println("<a href='ViewReviewServlet?name="+list.getName()+"' class='btn btn-info' role='button'>View Review</a>");
                                            out.println("</li>");
                                        }
                                    }
                                }
                            }

                            else if(category.equals("headphone")){
                                for(Map.Entry<String,List<Headphone>> map : hphashObj.entrySet()){
                                    for(Headphone list : map.getValue()){
                                        if(list.getId().equals(proId)){
                                            session.setAttribute("id", list.getId());
                                            session.setAttribute("price",list.getId());
                                            session.setAttribute("name", list.getName());
                                            
                                            carthashObj = (HashMap)session.getAttribute("sessionCart");
                                            if(carthashObj == null){
                                                carthashObj = new HashMap<String,Usercart>();
                                            }
                                            
                                            Usercart usercart = new Usercart();
                                            usercart.setProductId(list.getId());
                                            usercart.setPrice(list.getPrice());
                                            usercart.setProductName(list.getName());
                                            usercart.quantity = 1;

                                            carthashObj.put(String.valueOf(usercart.getProductId()), usercart);
	    	                                session.setAttribute("sessionCart", carthashObj);

                                            out.println("<li>");
                                                out.println("<img src=\"images/" + list.getImage() + "\" alt=\"Headphone\">");
                                                out.println("<h4>" + list.getName() + "</h4>");
                                                out.println("<p> Price-"+list.getPrice()+", Id-"+ list.getId()+", Retailer-"+ list.getRetailer()+", Condition-" + list.getCondition() +", Discount-" + list.getDiscount() + "</p>");                                   
                                                out.println("<a href='AddtoCartServlet?id="+ list.getId() +"' class='btn btn-info' role='button'>Add to cart</a>");
                                                out.println("<br>");
                                                out.println("<br>");
                                                out.println("<a href='WriteReviewServlet?name="+list.getName()+"&retailer="+list.getRetailer()+"&price="+list.getPrice()+"' class='btn btn-info' role='button'>Write Review</a>");
                                                out.println("<br>");
                                                out.println("<br>");
                                                out.println("<a href='ViewReviewServlet?name="+list.getName()+"' class='btn btn-info' role='button'>View Review</a>");
                                            out.println("</li>");
                                        }
                                    }
                                }
                            }

                            else if(category.equals("phone")){
                                for(Map.Entry<String,List<Phone>> map : phhashObj.entrySet()){
                                    for(Phone list : map.getValue()){
                                        if(list.getId().equals(proId)){
                                            session.setAttribute("id", list.getId());
                                            session.setAttribute("price",list.getPrice());
                                            session.setAttribute("name", list.getName());
                                            
                                            carthashObj = (HashMap)session.getAttribute("sessionCart");
                                            if(carthashObj == null){
                                                carthashObj = new HashMap<String,Usercart>();
                                            }
                                            
                                            Usercart usercart = new Usercart();
                                            usercart.setProductId(list.getId());
                                            usercart.setPrice(list.getPrice());
                                            usercart.setProductName(list.getName());
                                            usercart.quantity = 1;

                                            carthashObj.put(String.valueOf(usercart.getProductId()), usercart);
	    	                                session.setAttribute("sessionCart", carthashObj);

                                            out.println("<li>");
                                                out.println("<img src=\"images/" + list.getImage() + "\" alt=\"Smartwatch\">");
                                                out.println("<h4>" + list.getName() + "</h4>");
                                                out.println("<p> Price-"+list.getPrice()+", Id-"+ list.getId()+", Retailer-"+ list.getRetailer()+", Condition-" + list.getCondition() +", Discount-" + list.getDiscount() + "</p>");                                   
                                                out.println("<a href='AddtoCartServlet?id="+ list.getId() +"' class='btn btn-info' role='button'>Add to cart</a>");
                                                out.println("<br>");
                                                out.println("<br>");
                                                out.println("<a href='WriteReviewServlet?name="+list.getName()+"&retailer="+list.getRetailer()+"&price="+list.getPrice()+"' class='btn btn-info' role='button'>Write Review</a>");
                                                out.println("<br>");
                                                out.println("<br>");
                                                out.println("<a href='ViewReviewServlet?name="+list.getName()+"' class='btn btn-info' role='button'>View Review</a>");
                                            out.println("</li>");
                                        }
                                    }
                                }
                            }

                            else if(category.equals("laptop")){
                                for(Map.Entry<String,List<Laptop>> map : lphashObj.entrySet()){
                                    for(Laptop list : map.getValue()){
                                        if(list.getId().equals(proId)){
                                            session.setAttribute("id", list.getId());
                                            session.setAttribute("price",list.getPrice());
                                            session.setAttribute("name", list.getName());
                                            
                                            carthashObj = (HashMap)session.getAttribute("sessionCart");
                                            if(carthashObj == null){
                                                carthashObj = new HashMap<String,Usercart>();
                                            }
                                            
                                            Usercart usercart = new Usercart();
                                            usercart.setProductId(list.getId());
                                            usercart.setPrice(list.getPrice());
                                            usercart.setProductName(list.getName());
                                            usercart.quantity = 1;

                                            carthashObj.put(String.valueOf(usercart.getProductId()), usercart);
	    	                                session.setAttribute("sessionCart", carthashObj);

                                            out.println("<li>");
                                                out.println("<img src=\"images/" + list.getImage() + "\" alt=\"Smartwatch\">");
                                                out.println("<h4>" + list.getName() + "</h4>");
                                                out.println("<p> Price-"+list.getPrice()+", Id-"+ list.getId()+", Retailer-"+ list.getRetailer()+", Condition-" + list.getCondition() +", Discount-" + list.getDiscount() + "</p>");                                   
                                                out.println("<a href='AddtoCartServlet?id="+ list.getId() +"' class='btn btn-info' role='button'>Add to cart</a>");
                                                out.println("<br>");
                                                out.println("<br>");
                                                out.println("<a href='WriteReviewServlet?name="+list.getName()+"&retailer="+list.getRetailer()+"&price="+list.getPrice()+"' class='btn btn-info' role='button'>Write Review</a>");
                                                out.println("<br>");
                                                out.println("<br>");
                                                out.println("<a href='ViewReviewServlet?name="+list.getName()+"' class='btn btn-info' role='button'>View Review</a>");
                                            out.println("</li>");
                                        }
                                    }
                                }
                            }


                            else if(category.equals("externalstorage")){
                                for(Map.Entry<String,List<ExternalStorage>> map : eshashObj.entrySet()){
                                    for(ExternalStorage list : map.getValue()){
                                        if(list.getId().equals(proId)){
                                            session.setAttribute("id", list.getId());
                                            session.setAttribute("price",list.getPrice());
                                            session.setAttribute("name", list.getName());
                                            
                                            carthashObj = (HashMap)session.getAttribute("sessionCart");
                                            if(carthashObj == null){
                                                carthashObj = new HashMap<String,Usercart>();
                                            }
                                            
                                            Usercart usercart = new Usercart();
                                            usercart.setProductId(list.getId());
                                            usercart.setPrice(list.getPrice());
                                            usercart.setProductName(list.getName());
                                            usercart.quantity = 1;

                                            carthashObj.put(String.valueOf(usercart.getProductId()), usercart);
	    	                                session.setAttribute("sessionCart", carthashObj);

                                            out.println("<li>");
                                                out.println("<img src=\"images/" + list.getImage() + "\" alt=\"Smartwatch\">");
                                                out.println("<h4>" + list.getName() + "</h4>");
                                                out.println("<p> Price-"+list.getPrice()+", Id-"+ list.getId()+", Retailer-"+ list.getRetailer()+", Condition-" + list.getCondition() +", Discount-" + list.getDiscount() + "</p>");                                   
                                                out.println("<a href='AddtoCartServlet?id="+ list.getId() +"' class='btn btn-info' role='button'>Add to cart</a>");
                                                out.println("<br>");
                                                out.println("<br>");
                                                out.println("<a href='WriteReviewServlet?name="+list.getName()+"&retailer="+list.getRetailer()+"&price="+list.getPrice()+"' class='btn btn-info' role='button'>Write Review</a>");
                                                out.println("<br>");
                                                out.println("<br>");
                                                out.println("<a href='ViewReviewServlet?name="+list.getName()+"' class='btn btn-info' role='button'>View Review</a>");
                                            out.println("</li>");
                                        }
                                    }
                                }
                            }

                            else if(category.equals("accessory")){
                                for(Map.Entry<String,List<Accessory>> map : achashObj.entrySet()){
                                    for(Accessory list : map.getValue()){
                                        if(list.getId().equals(proId)){
                                            session.setAttribute("id", list.getId());
                                            session.setAttribute("price",list.getId());
                                            session.setAttribute("name", list.getName());
                                            
                                            carthashObj = (HashMap)session.getAttribute("sessionCart");
                                            if(carthashObj == null){
                                                carthashObj = new HashMap<String,Usercart>();
                                            }
                                            
                                            Usercart usercart = new Usercart();
                                            usercart.setProductId(list.getId());
                                            usercart.setPrice(list.getPrice());
                                            usercart.setProductName(list.getName());
                                            usercart.quantity = 1;

                                            carthashObj.put(String.valueOf(usercart.getProductId()), usercart);
	    	                                session.setAttribute("sessionCart", carthashObj);

                                            out.println("<li>");
                                                out.println("<img src=\"images/" + list.getImage() + "\" alt=\"Headphone\">");
                                                out.println("<h4>" + list.getName() + "</h4>");
                                                out.println("<p> Price-"+list.getPrice()+", Id-"+ list.getId()+", Condition-" + list.getCondition() +"</p>");                                   
                                                out.println("<a href='AddtoCartServlet?id="+ list.getId() +"' class='btn btn-info' role='button'>Add to cart</a>");
                                                out.println("<br>");
                                                out.println("<br>");
                                                out.println("<a href='WriteReviewServlet?name="+list.getName()+"&price="+list.getPrice()+"' class='btn btn-info' role='button'>Write Review</a>");
                                                out.println("<br>");
                                                out.println("<br>");
                                                out.println("<a href='ViewReviewServlet?name="+list.getName()+"' class='btn btn-info' role='button'>View Review</a>");
                                            out.println("</li>");
                                        }
                                    }
                                }
                            }
                            
                            	
                            out.println("</ul>");	
                        out.println("</article>");			 
                    out.println("</section>");
        
                    out.println("<aside class=\"sidebar\">");
	
                    out.println("<ul>");	
                        out.println(" <li>");
                            out.println("<h4>Categories</h4>");
                            out.println("<ul>");                                
                                out.println("<li><a href=\"TrendingServlet\">Trending</a></li>");
                                out.println("<li><a href=\"ShowProductServlet?productid=smartwatch\">Smart Watches</a></li>");
                                out.println("<li><a href=\"ShowProductServlet?productid=speaker\">Speakers</a></li>");
                                out.println("<li><a href=\"ShowProductServlet?productid=headphone\">Headphones</a></li>");
                                out.println("<li><a href=\"ShowProductServlet?productid=phone\">Phones</a></li>");
                                out.println("<li><a href=\"ShowProductServlet?productid=laptop\">Laptops</a></li>");
                                out.println("<li><a href=\"ShowProductServlet?productid=externalstorage\">External Storage</a></li>");
                                out.println("<li><a href=\"ShowProductServlet?productid=accessory\">Accessories</a></li>");
                                out.println("<li><a href=\"TrendingServlet\">Trending</a></li>");
                            out.println("</ul>");
                        out.println("</li>");
                
                        out.println(" <li>");
                            out.println("<h4>About us</h4>");
                            out.println("<ul>");
                                out.println("<li class=\"text\">");
                                    out.println("<p style=\"margin: 0;\">The secret of successful retailing is to give your customers what they want. And really, if you think about it from your point of view as a customer, you want everything: a wide assortment of good-quality merchandise; the lowest possible prices; guaranteed satisfaction with what you buy.<a href class=\"readmore\">Read More &raquo;</a></p>");
                                out.println("</li>");
                            out.println("</ul>");
                        out.println("</li>");
                
                        out.println("<li>");
                            out.println("<h4>Search site</h4>");
                            out.println("<ul>");
                                out.println("<li class=\"text\">");
                                    out.println("<form method=\"get\" class=\"searchform\" action >");
                                        out.println("<p>");
                                            out.println(" <input type=\"text\" size=\"30.5\"  name=\"s\" class=\"s\" placeholder=\"Search...\" />");
                                            
                                        out.println(" </p>");
                                    out.println(" </form>");	
                                out.println("</li>");
                            out.println("</ul>");
                        out.println("</li>");
                
                    out.println("</ul>");
                    out.println("</aside>");
    	            out.println("<div class=\"clear\"></div>");
     

                    out.println("<section>");
                        out.println("<article class=\"expanded\">");
                           
                        out.println("</article>");
                    out.println("</section>");

                out.println("</div>");
    
                out.println("<footer>");
                    out.println("<div class=\"footer-content\">");
                        out.println("<ul>");
                            out.println("<li><h4>Proin accumsan</h4></li>");
                            out.println("<li><a href=\"#\">Rutrum nulla a ultrices</a></li>");
                            out.println("<li><a href=\"#\">Blandit elementum</a></li>");
                            out.println("<li><a href=\"#\">Proin placerat accumsan</a></li>");
                        out.println("</ul>");
             
                        out.println("<ul>");
                            out.println("<li><h4>Proin accumsan</h4></li>");
                            out.println("<li><a href=\"#\">Rutrum nulla a ultrices</a></li>");
                            out.println("<li><a href=\"#\">Blandit elementum</a></li>");
                            out.println("<li><a href=\"#\">Proin placerat accumsan</a></li>");
                        out.println("</ul>");
            
                        out.println("<ul>");
                            out.println("<li><h4>Proin accumsan</h4></li>");
                            out.println("<li><a href=\"#\">Rutrum nulla a ultrices</a></li>");
                            out.println("<li><a href=\"#\">Blandit elementum</a></li>");
                            out.println("<li><a href=\"#\">Proin placerat accumsan</a></li>");
                        out.println("</ul>");
            
                        out.println("<div class=\"clear\"></div>");
                    out.println("</div>");
                    out.println("<div class=\"footer-bottom\">");
                        out.println("<p>&copy; Smart Portables 2017.</p>");
                     out.println("</div>");
                out.println("</footer>");
            out.println("</div>");
        out.println("</body>");
    out.println("</html>");  
    }
}